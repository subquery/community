import os
# Function to rename multiple files

path="/Users/james/Development/subquery/community/migration/customer/"

def addDateToName():
	i = 0
	for filename in os.listdir(path):
		my_dest = "{}-{}-{}-{}".format(filename[0:4], filename[4:6], filename[6:8], filename[9:])
		print(my_dest)
		my_source = path + filename
		my_dest = path + my_dest
		# rename() function will
		# rename all the files
		os.rename(my_source, my_dest)
		i += 1

def prependFrontmatter():
	for filename in os.listdir(path):
		with open(filename, "r+") as f:
			title = f.readline()
			old = f.read() # read everything in the file
			f.seek(0) # rewind
			print("---\ntitle: " + title[2:] + "category: customer announcements\ntag: customer announcements\n---\n")
			f.write("---\ntitle: " + title[2:] + "category: customer announcements\ntag: customer announcements\n---\n" + old)

#addDateToName()
prependFrontmatter()